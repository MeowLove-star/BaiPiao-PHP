-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2019-07-13 11:09:23
-- 服务器版本： 10.1.37-MariaDB
-- PHP 版本： 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `www_baipiao_com`
--
CREATE DATABASE IF NOT EXISTS `www_baipiao_com` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `www_baipiao_com`;

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `commentId` int(255) UNSIGNED NOT NULL,
  `userId` int(255) UNSIGNED NOT NULL,
  `videoId` int(255) UNSIGNED NOT NULL,
  `comment` char(255) NOT NULL,
  `commentDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 插入之前先把表清空（truncate） `comment`
--

TRUNCATE TABLE `comment`;
-- --------------------------------------------------------

--
-- 表的结构 `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification` (
  `notificationId` int(255) UNSIGNED NOT NULL,
  `userId` int(255) UNSIGNED NOT NULL,
  `notification` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 插入之前先把表清空（truncate） `notification`
--

TRUNCATE TABLE `notification`;
-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(255) UNSIGNED NOT NULL,
  `userPic` char(255) DEFAULT NULL,
  `userName` char(30) NOT NULL,
  `userPassword` char(255) NOT NULL,
  `userEmail` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 插入之前先把表清空（truncate） `user`
--

TRUNCATE TABLE `user`;
--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`userId`, `userPic`, `userName`, `userPassword`, `userEmail`) VALUES
(1, NULL, '白漂佬', 'bc6c0f32257e7bbc8b4db57234975aad', 'admin@baipiao.com'),
(2, NULL, 'admin', 'admin', '');

-- --------------------------------------------------------

--
-- 表的结构 `video`
--

DROP TABLE IF EXISTS `video`;
CREATE TABLE `video` (
  `videoId` int(255) UNSIGNED NOT NULL,
  `videoType` char(255) NOT NULL,
  `videoUrl` char(255) NOT NULL,
  `videoPic` char(255) NOT NULL,
  `videoTitle` char(255) NOT NULL,
  `videoIntroduction` char(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `userId` int(255) UNSIGNED NOT NULL,
  `playVolume` int(255) UNSIGNED NOT NULL DEFAULT '0',
  `commentVolume` int(255) UNSIGNED NOT NULL DEFAULT '0',
  `danmukeVolume` int(255) UNSIGNED NOT NULL DEFAULT '0',
  `videoStatus` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 插入之前先把表清空（truncate） `video`
--

TRUNCATE TABLE `video`;
--
-- 转存表中的数据 `video`
--

INSERT INTO `video` (`videoId`, `videoType`, `videoUrl`, `videoPic`, `videoTitle`, `videoIntroduction`, `create_time`, `update_time`, `userId`, `playVolume`, `commentVolume`, `danmukeVolume`, `videoStatus`) VALUES
(1, 'test', '', '', 'test', 'test', 0, 0, 1, 1, 1, 1, 1),
(2, 'testHaHa', '', '', 'test', 'test', 0, 0, 1, 1, 1, 1, 1),
(3, 'mv', '', '', '国豪', 'ok', 1563006340, 1563006340, 0, 0, 0, 0, 0),
(4, 'mv', '', '', '国豪', 'ok', 1563006439, 1563006439, 2, 0, 0, 0, 0),
(5, 'music', '', '', 'jesus', 'ok', 1563006582, 1563006582, 2, 0, 0, 0, 0);

--
-- 转储表的索引
--

--
-- 表的索引 `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`commentId`);

--
-- 表的索引 `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notificationId`);

--
-- 表的索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- 表的索引 `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`videoId`),
  ADD KEY `userId` (`userId`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `comment`
--
ALTER TABLE `comment`
  MODIFY `commentId` int(255) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `notification`
--
ALTER TABLE `notification`
  MODIFY `notificationId` int(255) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `userId` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `video`
--
ALTER TABLE `video`
  MODIFY `videoId` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
